DUTY: Upload these 3 HTML files to GitHub Pages.

Files:
- index.html
- tuesday.html
- wednesday.html

After GitHub Pages publishes the site, the URLs will be:
https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/tuesday.html
https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/wednesday.html

Then create one QR code for each URL.

IMPORTANT:
GitHub Pages is public. The guest names and table assignments are embedded in the pages. Anyone who can inspect the page source could potentially see the list. Do not use this setup if the table assignments must remain confidential.
